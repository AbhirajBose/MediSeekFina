<?php

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Autocomplete Search Box | CodingNepal</title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  </head>
  <body>
    <div class="wrapper">
      <div class="search-input">
        <a href="" target="_blank" hidden></a>
        <form action="index.php" method="POST">
        <input name="data" type="text" placeholder="Type to search..">
        </form>
        <?php
    if(!empty($_POST)){
        $q = $_POST["data"]; 
        ?>
        <div class="autocom-box">
          <!-- here list are inserted from javascript -->
        </div>
        <div class="icon"><i class="fas fa-search"></i></div>
        <form action="" method=""></form>
      </div>
      <?php
        $output = passthru('python test.py '.$q);
        echo $output;
    }
    ?>
    </div>

    <script src="js/suggestions.js"></script>
    <script src="js/script.js"></script>

  </body>
</html>
